package com.task.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.student.dto.FetchAllStudents;
import com.task.student.dto.StudentDto;
import com.task.student.entity.Student;
import com.task.student.exception.StudentNotFoundException;
import com.task.student.service.StudentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/student")
@Slf4j
public class StudentController {

	@Autowired
	private StudentService studentService;

	// Url : http://localhost:8085/student/addStudent

	/**
	 * @param studentDto
	 * @return It will insert the the student details into database
	 */
	@PostMapping("/addStudent")
	public ResponseEntity<Student> addStudent(@RequestBody StudentDto studentDto) {

		if (studentDto != null) {

			log.info(studentDto + "  Students Details Inserted Successfully..");
			Student student = studentService.addStudent(studentDto);
			return new ResponseEntity<>(student, HttpStatus.CREATED);
		} else {
			log.error("Students Details are not inserted!!!");
			throw new StudentNotFoundException("Student Details are not Inserted!!");
		}
	}

	// Url : http://localhost:8085/student/getAllStudents

	/**
	 * @return It Will return All Student Details with his subjects information.
	 */
	@GetMapping("/getAllStudents")
	public ResponseEntity<List<FetchAllStudents>> getAllStudents() {
		List<FetchAllStudents> students = studentService.getAllStudents();
		if (!students.isEmpty()) {
			log.info("Students Details Fetched Successfully..");
			return new ResponseEntity<>(students, HttpStatus.OK);
		} else {
			log.error("Students Details are not Fetched!!!");
			throw new StudentNotFoundException("Student Details are not found!!");
		}
	}

}
